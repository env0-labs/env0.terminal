namespace env0.terminal.Terminal
{
    public class CommandParser
    {
        // TODO: Implement command parsing logic
    }
}
