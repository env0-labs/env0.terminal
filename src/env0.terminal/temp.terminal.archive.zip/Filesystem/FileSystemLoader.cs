namespace env0.terminal.Filesystem
{
    public class FileSystemLoader
    {
        // TODO: Implement filesystem loading from JSON
    }
}
