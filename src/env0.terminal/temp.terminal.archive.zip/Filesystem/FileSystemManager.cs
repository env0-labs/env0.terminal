namespace env0.terminal.Filesystem
{
    public class FileSystemManager
    {
        // TODO: Implement virtual filesystem management
    }
}
