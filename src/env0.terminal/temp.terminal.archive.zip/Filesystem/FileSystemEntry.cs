namespace env0.terminal.Filesystem
{
    public class FileSystemEntry
    {
        // TODO: Implement file/directory data structure
    }
}
