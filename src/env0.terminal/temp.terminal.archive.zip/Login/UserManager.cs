namespace env0.terminal.Login
{
    public class UserManager
    {
        // TODO: Implement user management
    }
}
