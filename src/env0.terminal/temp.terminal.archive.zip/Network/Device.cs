namespace env0.terminal.Network
{
    public class Device
    {
        // TODO: Implement device model
    }
}
