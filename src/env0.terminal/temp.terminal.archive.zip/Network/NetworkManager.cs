namespace env0.terminal.Network
{
    public class NetworkManager
    {
        // TODO: Implement network logic
    }
}
