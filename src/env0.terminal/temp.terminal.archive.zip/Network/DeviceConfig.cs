namespace env0.terminal.Network
{
    public class DeviceConfig
    {
        // TODO: Implement device config
    }
}
